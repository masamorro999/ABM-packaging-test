# ABM-PI2

This code has made to create a population of 5 agents, set their characteristics and finally it shows these characteristics

**To build the project execute the next lines:**

`$ mkdir build lib ; cd build`

`$ cmake .. ; make`

**After go to bin folder and run**:

`$ ./ABM-Wall-E`
